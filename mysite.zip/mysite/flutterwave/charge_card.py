#
# # CHARGE CARD
#
from django.shortcuts import render, redirect
from flutterwave import Flutterwave
from django.http import HttpResponse, JsonResponse
from django.core.urlresolvers import reverse
from django.contrib import messages
flw = Flutterwave("", "", {"debug": True})

data = {
    "amount": "100",                           # Amount to debit from card
    "authModel": "BVN",                        # authentication Model - BVN, PIN, NOAUTH, VBVSECURECODE
    "cardNumber": "4842508225502547",          # Card Number
    "cvv": "136",                              # Card CVV
    "expiryMonth": "10",                       # Card expiry month
    "expiryYear": "18",                        # Card expiry year
    "bvn": "12345678901",                      # (Optional) User BVN, required only for authModel=BVN
    "currency": "NGN",                         # Transaction currency
    "customerID": "cust1471629671",            # Customer ID for tracking charge transaction
    "narration": "sample card purchase",       # Transaction description
    "responseUrl": "http://your_callback_url", # Callback Url
    "currency": "NGN",                         # Transaction currency
    "country": "NGN"                           # Country code (NGN)
}

r = flw.card.charge(data)
print "{}".format(r.text)