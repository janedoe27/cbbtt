from django.apps import AppConfig


class FlutterwaveConfig(AppConfig):
    name = 'charge_card'
